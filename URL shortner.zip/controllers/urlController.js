const shortid = require('shortid');

// In-memory storage for URLs
const urlDatabase = {};

const generateShortCode = () => shortid.generate().substring(0, 6);

const shortenUrl = async (req, res) => {
  try {
    const { longUrl } = req.body;
    const baseUrl = process.env.BASE_URL;

    // Check if URL already exists in memory
    const existingUrl = Object.values(urlDatabase).find(url => url.originalUrl === longUrl);

    if (existingUrl) {
      return res.json({
        success: true,
        originalUrl: existingUrl.originalUrl,
        shortUrl: existingUrl.shortUrl,
        urlCode: existingUrl.urlCode
      });
    }

    // Generate URL code
    const urlCode = generateShortCode();
    const shortUrl = `${baseUrl}/${urlCode}`;

    // Create new URL entry in memory
    const newUrl = {
      originalUrl: longUrl,
      urlCode,
      shortUrl,
      clicks: 0,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
    };

    // Save to memory
    urlDatabase[urlCode] = newUrl;

    res.status(201).json({
      success: true,
      originalUrl: longUrl,
      shortUrl,
      urlCode,
      expiresAt: newUrl.expiresAt
    });
  } catch (error) {
    console.error('Error shortening URL:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Server error' 
    });
  }
};

const redirectToOriginalUrl = async (req, res) => {
  try {
    const { code } = req.params;
    
    // Find URL in memory
    const url = urlDatabase[code];

    if (!url) {
      return res.status(404).json({
        success: false,
        error: 'URL not found or expired'
      });
    }

    // Update clicks and last accessed time
    url.clicks += 1;
    url.lastAccessed = new Date();

    res.redirect(url.originalUrl);
  } catch (error) {
    console.error('Error redirecting:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Server error' 
    });
  }
};

const getUrlStats = async (req, res) => {
  try {
    const { code } = req.params;
    
    // Find URL in memory
    const url = urlDatabase[code];

    if (!url) {
      return res.status(404).json({
        success: false,
        error: 'URL not found or expired'
      });
    }

    res.json({
      success: true,
      data: {
        originalUrl: url.originalUrl,
        shortUrl: url.shortUrl,
        clicks: url.clicks || 0,
        createdAt: url.createdAt,
        lastAccessed: url.lastAccessed,
        expiresAt: url.expiresAt
      }
    });
  } catch (error) {
    console.error('Error getting URL stats:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Server error' 
    });
  }
};

module.exports = {
  shortenUrl,
  redirectToOriginalUrl,
  getUrlStats
};
