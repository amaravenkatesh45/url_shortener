const express = require('express');
const router = express.Router();
const { validateUrl } = require('../validators/urlValidator');
const { 
  shortenUrl, 
  redirectToOriginalUrl, 
  getUrlStats 
} = require('../controllers/urlController');
const rateLimit = require('express-rate-limit');

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per window
  message: 'Too many requests from this IP, please try again later.'
});

// Route to create a short URL
router.post('/shorten', apiLimiter, validateUrl, shortenUrl);

// Route to get URL statistics
router.get('/:code/stats', getUrlStats);

module.exports = router;
