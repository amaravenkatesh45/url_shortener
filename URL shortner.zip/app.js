require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const connectDB = require('./config/db');
const urlRoutes = require('./routes/url');
const { errorHandler, notFound } = require('./middleware/error');

// Initialize Express app
const app = express();

// Connect to MongoDB
// connectDB(); // Commented out for in-memory storage

// Middleware
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date() });
});

// URL routes
app.use('/api', urlRoutes);

// Handle short URL redirects (must come after other routes)
app.get('/:code', (req, res, next) => {
  // Skip if the request is for a static file
  if (req.path.includes('.')) {
    return next();
  }
  // Delegate to the URL controller
  const { redirectToOriginalUrl } = require('./controllers/urlController');
  return redirectToOriginalUrl(req, res, next);
});

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error(`Error: ${err.message}`);
  // Close server & exit process
  server.close(() => process.exit(1));
});

module.exports = app;
